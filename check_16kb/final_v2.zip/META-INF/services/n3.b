n3.b
